"""Lembah Karsa game package."""
